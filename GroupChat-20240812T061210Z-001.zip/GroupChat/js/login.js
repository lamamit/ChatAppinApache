$( function() {
    $( "input" ).checkboxradio();
  } );
