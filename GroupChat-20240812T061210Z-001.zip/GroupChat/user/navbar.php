<nav class="navbar navbar-default">
    <div style="background-color: #3399CC; "class="container-fluid">
		<div class="navbar-header">
            <a style="font-size: 60px; font-style: italic" class="navbar-brand" href="">NEPTALK</a>
		</div>
		
		<ul class="nav navbar-nav">
			<li><a style="font-size: 30px;" href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
		</ul>
		
		<ul class="nav navbar-nav navbar-right">
			<li><a style="font-size: 20px;" href="#account" data-toggle="modal"><span class="glyphicon glyphicon-lock"></span> <?php echo $user; ?></a></li>
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
                    <ul  style="background-color: lightblue; font-size: 20px; " class="dropdown-menu">
						<li><a  href="#photo" data-toggle="modal"><span class="glyphicon glyphicon-picture"></span> Update Photo</a></li>
						<li class="divider"></li>
                        <li><a href="#logout" data-toggle="modal"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                    </ul>
			</li>
		</ul> 
    </div>
</nav>