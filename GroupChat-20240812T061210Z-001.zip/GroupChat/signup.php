
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="../../../../favicon.ico">

  <title>Neptalk</title>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <link rel="stylesheet" href="css/register.css">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">


</head>
   


<body onload="document.form1">
    
  <article class="card-body mx-auto" style="max-width: 400px;">
    
  
    <form name="form1" action="register.php" method="post">
    
        <!-- Display Validation errors over here -->
        <center><img class="mb-4" src="kdu.PNG" alt="" width="72" height="72"></center>
    <h2 class="card-title mt-3 text-center">Register</h2>
     <div class="form-group input-group">
        <div class="input-group-prepend">
          <span class="input-group-text"> <i class="fa fa-user"></i> </span>
        </div>
        <input class="form-control" placeholder="Name" type="text" name="name" value="">
      </div> <!-- form-group// -->
      <div class="form-group input-group">
        <div class="input-group-prepend">
          <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
        </div>
        <input class="form-control" placeholder="Username" type="text" name="username" value="">
      </div> <!-- form-group// -->
       
      <div class="form-group input-group">
        <div class="input-group-prepend">
          <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
        </div>
        <input class="form-control" placeholder="Password" type="password" name="password" value="">
      </div> 
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-block" onclick="validate();" name="createAccount"> Create Account </button>
      </div> <!-- form-group// -->
      <p class="text-center">Have an account? <a href="index.php">Log In</a> </p>
    </form>
  </article>
  

  </div>
  </article>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="js/register.js"></script>
<?php
   session_start();
    if(isset($_SESSION['sign_msg'])){
     echo $_SESSION['sign_msg'];
       unset($_SESSION['sign_msg']);
				}
			?>

</body>

</html>
